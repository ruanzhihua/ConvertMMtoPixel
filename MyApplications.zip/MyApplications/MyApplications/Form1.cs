﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyApplications
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void theFirstNum_TextChanged(object sender, EventArgs e)
        {

        }

        private void theFirstNum_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode==Keys.Enter)
            {
                this.thePixel.Text = (int.Parse(this.theFirstNum.Text) / 25.4 * int.Parse(this.theSecondNum.Text)).ToString();
            }
        }

        private void thePixel_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.theFirstNum.Text = (int.Parse(this.thePixel.Text) / int.Parse(this.theSecondNum.Text)*25.4).ToString();
            }
        }
    }
}
